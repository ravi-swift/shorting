//
//  ViewController.swift
//  shorting
//
//  Created by Rp on 20/12/18.
//  Copyright © 2018 Dharmesh Sonani. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var array1 = [["Name":"Xyz","Age":"25","Place":"Surat"],["Name":"ABC","Age":"18","Place":"Abc"],["Name":"Opq","Age":"20","Place":"A"],["Name":"Mno","Age":"21","Place":"ZC"],["Name":"Bcd","Age":"22","Place":"Ad"]]
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let arrayObject = NSArray.init(array: array1)

        let descriptor = NSSortDescriptor.init(key: "Age", ascending: true)

        let sortArray = arrayObject.sortedArray(using: [descriptor])
        
        print(sortArray)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

